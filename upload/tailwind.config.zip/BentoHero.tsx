'use client';

import { motion } from 'framer-motion';
import { StatCard } from './StatCard';
import { Map, BarChart3, Shield, Layers } from 'lucide-react';

export function BentoHero() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-5xl mx-auto">
      {/* Large featured card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="md:col-span-2 md:row-span-2 relative overflow-hidden rounded-2xl
          bg-gradient-to-br from-pip-500/10 via-pip-500/5 to-transparent
          border border-pip-500/20 backdrop-blur-xl
          p-8 flex flex-col justify-between min-h-[280px]"
      >
        {/* Animated background */}
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-0 right-0 w-64 h-64 bg-pip-500/20 rounded-full blur-3xl" />
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-pip-400/10 rounded-full blur-3xl" />
        </div>

        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-4">
            <Shield className="w-5 h-5 text-pip-400" />
            <span className="text-xs font-medium text-pip-400 tracking-wider uppercase">
              Verified Data
            </span>
          </div>
          <h2 className="text-3xl font-bold text-white mb-2">
            DOSM kawasanku
            <span className="text-gradient"> GeoJSON</span>
          </h2>
          <p className="text-zinc-400 text-sm max-w-md">
            Real boundary data from Department of Statistics Malaysia. 
            2026 redelineation verified against official gazette.
          </p>
        </div>

        <div className="relative z-10 flex items-end gap-6 mt-6">
          <div>
            <div className="font-mono text-4xl font-bold text-white">6</div>
            <div className="text-xs text-zinc-500 mt-1">Parliaments</div>
          </div>
          <div className="w-px h-10 bg-zinc-800" />
          <div>
            <div className="font-mono text-4xl font-bold text-white">28</div>
            <div className="text-xs text-zinc-500 mt-1">DUN Seats</div>
          </div>
          <div className="w-px h-10 bg-zinc-800" />
          <div>
            <div className="font-mono text-4xl font-bold text-white">3</div>
            <div className="text-xs text-zinc-500 mt-1">Elections</div>
          </div>
        </div>
      </motion.div>

      {/* Smaller cards */}
      <StatCard 
        value={28} 
        label="DUN Seats" 
        description="N01–N28"
        verified={true}
        delay={0.1}
        icon={<Layers className="w-4 h-4" />}
      />
      <StatCard 
        value={34} 
        label="GeoJSON Layers" 
        description="DUN + Parlimen"
        verified={true}
        delay={0.15}
        icon={<Map className="w-4 h-4" />}
      />
      <StatCard 
        value={71415} 
        label="Total Voters" 
        description="P134 verified"
        verified={true}
        delay={0.2}
        icon={<BarChart3 className="w-4 h-4" />}
      />
      <StatCard 
        value={5} 
        label="Pending" 
        description="Parliaments"
        verified={false}
        delay={0.25}
      />
    </div>
  );
}
