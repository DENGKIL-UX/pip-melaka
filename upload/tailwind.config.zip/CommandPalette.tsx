'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, MapPin, Building2, ArrowRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface CommandItem {
  id: string;
  title: string;
  subtitle: string;
  type: 'parliament' | 'dun' | 'action';
  icon?: React.ReactNode;
}

const commands: CommandItem[] = [
  { id: 'p134', title: 'P134 — Masjid Tanah', subtitle: 'Alor Gajah · 5 DUN · 71,415 voters', type: 'parliament' },
  { id: 'p135', title: 'P135 — Alor Gajah', subtitle: 'Alor Gajah · 5 DUN · pending', type: 'parliament' },
  { id: 'p136', title: 'P136 — Tangga Batu', subtitle: 'Melaka Tengah · 4 DUN · pending', type: 'parliament' },
  { id: 'p137', title: 'P137 — Hang Tuah Jaya', subtitle: 'Melaka Tengah · 4 DUN · pending', type: 'parliament' },
  { id: 'p138', title: 'P138 — Kota Melaka', subtitle: 'Melaka Tengah · 5 DUN · pending', type: 'parliament' },
  { id: 'p139', title: 'P139 — Jasin', subtitle: 'Jasin · 5 DUN · pending', type: 'parliament' },
  { id: 'map', title: 'Open Map View', subtitle: 'Interactive DUN boundary map', type: 'action' },
  { id: 'export', title: 'Export Data', subtitle: 'Download GeoJSON + CSV', type: 'action' },
];

export function CommandPalette({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState(0);

  const filtered = query === '' 
    ? commands 
    : commands.filter(c => 
        c.title.toLowerCase().includes(query.toLowerCase()) ||
        c.subtitle.toLowerCase().includes(query.toLowerCase())
      );

  useEffect(() => {
    setSelected(0);
  }, [query]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        open ? onClose() : null;
      }
      if (!open) return;
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelected(s => (s + 1) % filtered.length);
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelected(s => (s - 1 + filtered.length) % filtered.length);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [open, filtered.length, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100]"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: -20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -20 }}
            transition={{ duration: 0.2 }}
            className="fixed top-[20%] left-1/2 -translate-x-1/2 w-full max-w-lg z-[101]"
          >
            <div className="rounded-xl bg-zinc-950 border border-white/[0.08] shadow-2xl overflow-hidden">
              {/* Search input */}
              <div className="flex items-center gap-3 px-4 py-3 border-b border-white/[0.08]">
                <Search className="w-4 h-4 text-zinc-500" />
                <input
                  autoFocus
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search parliaments, DUNs, or actions..."
                  className="flex-1 bg-transparent text-sm text-white placeholder-zinc-600 outline-none"
                />
                <kbd className="px-1.5 py-0.5 rounded bg-white/[0.08] text-[10px] font-mono text-zinc-500">
                  ESC
                </kbd>
              </div>

              {/* Results */}
              <div className="max-h-80 overflow-y-auto custom-scrollbar py-2">
                {filtered.length === 0 ? (
                  <div className="px-4 py-8 text-center text-sm text-zinc-600">
                    No results found
                  </div>
                ) : (
                  filtered.map((item, i) => (
                    <div
                      key={item.id}
                      className={cn(
                        'flex items-center gap-3 px-4 py-2.5 cursor-pointer transition-colors',
                        selected === i 
                          ? 'bg-white/[0.08]' 
                          : 'hover:bg-white/[0.04]'
                      )}
                      onMouseEnter={() => setSelected(i)}
                    >
                      <div className={cn(
                        'w-8 h-8 rounded-lg flex items-center justify-center',
                        item.type === 'parliament' ? 'bg-pip-500/10' : 'bg-zinc-800'
                      )}>
                        {item.type === 'parliament' ? (
                          <Building2 className="w-4 h-4 text-pip-400" />
                        ) : (
                          <MapPin className="w-4 h-4 text-zinc-500" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm text-white truncate">{item.title}</div>
                        <div className="text-xs text-zinc-500 truncate">{item.subtitle}</div>
                      </div>
                      {selected === i && (
                        <ArrowRight className="w-3.5 h-3.5 text-pip-400" />
                      )}
                    </div>
                  ))
                )}
              </div>

              {/* Footer */}
              <div className="px-4 py-2 border-t border-white/[0.08] flex items-center gap-4 text-[10px] text-zinc-600">
                <span className="flex items-center gap-1">
                  <kbd className="px-1 rounded bg-white/[0.08]">↑↓</kbd> Navigate
                </span>
                <span className="flex items-center gap-1">
                  <kbd className="px-1 rounded bg-white/[0.08]">↵</kbd> Select
                </span>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
