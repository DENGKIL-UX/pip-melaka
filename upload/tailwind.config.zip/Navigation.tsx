'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import { Menu, X, Search, Bell, Command } from 'lucide-react';

export function Navigation() {
  const [isOpen, setIsOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  const navItems = [
    { label: 'Dashboard', href: '#', active: true },
    { label: 'Parliaments', href: '#parliaments' },
    { label: 'DUN Map', href: '#map' },
    { label: 'Analytics', href: '#analytics' },
    { label: 'Settings', href: '#settings' },
  ];

  return (
    <motion.header
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="fixed top-0 left-0 right-0 z-50"
    >
      <div className="mx-4 mt-4">
        <nav className="max-w-6xl mx-auto rounded-xl
          bg-zinc-950/80 backdrop-blur-2xl
          border border-white/[0.08]
          px-4 py-3 flex items-center justify-between">

          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-pip-500 to-pip-600 
              flex items-center justify-center shadow-glow">
              <span className="font-mono font-bold text-sm text-zinc-950">PIP</span>
            </div>
            <div className="hidden sm:block">
              <div className="text-sm font-semibold text-white">PIP-MLK</div>
              <div className="text-[10px] text-zinc-500 -mt-0.5">Political Intelligence Platform</div>
            </div>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className={cn(
                  'px-3 py-1.5 rounded-lg text-sm transition-all duration-200',
                  item.active
                    ? 'bg-white/[0.08] text-white font-medium'
                    : 'text-zinc-400 hover:text-white hover:bg-white/[0.04]'
                )}
              >
                {item.label}
              </a>
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setSearchOpen(true)}
              className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg
                bg-white/[0.04] border border-white/[0.08]
                text-zinc-500 text-sm hover:bg-white/[0.08] transition-colors"
            >
              <Search className="w-3.5 h-3.5" />
              <span className="text-xs">Search...</span>
              <kbd className="ml-2 px-1.5 py-0.5 rounded bg-white/[0.08] text-[10px] font-mono">
                ⌘K
              </kbd>
            </button>

            <button className="relative p-2 rounded-lg hover:bg-white/[0.08] transition-colors">
              <Bell className="w-4 h-4 text-zinc-400" />
              <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-pip-500 rounded-full" />
            </button>

            <button 
              className="md:hidden p-2 rounded-lg hover:bg-white/[0.08] transition-colors"
              onClick={() => setIsOpen(!isOpen)}
            >
              {isOpen ? <X className="w-4 h-4 text-zinc-400" /> : <Menu className="w-4 h-4 text-zinc-400" />}
            </button>
          </div>
        </nav>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="mx-4 mt-2 rounded-xl bg-zinc-950/95 backdrop-blur-2xl
              border border-white/[0.08] p-4 md:hidden"
          >
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className={cn(
                  'block px-4 py-3 rounded-lg text-sm transition-colors',
                  item.active
                    ? 'bg-white/[0.08] text-white font-medium'
                    : 'text-zinc-400 hover:text-white hover:bg-white/[0.04]'
                )}
              >
                {item.label}
              </a>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
