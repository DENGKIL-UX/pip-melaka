'use client';

import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { MapPin, Users, Building2, ChevronRight } from 'lucide-react';

interface ParliamentCardProps {
  code: string;
  name: string;
  district: string;
  dunCount: number;
  voters: number | null;
  verified: boolean;
  delay?: number;
  onClick?: () => void;
}

export function ParliamentCard({
  code,
  name,
  district,
  dunCount,
  voters,
  verified,
  delay = 0,
  onClick,
}: ParliamentCardProps) {
  const completeness = verified ? 100 : 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay, ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ y: -2 }}
      onClick={onClick}
      className={cn(
        'group relative cursor-pointer',
        'rounded-xl overflow-hidden',
        'bg-white/[0.03] backdrop-blur-xl',
        'border border-white/[0.08]',
        'hover:border-pip-500/20',
        'transition-all duration-300',
        'shadow-card hover:shadow-card-hover',
        'p-5'
      )}
    >
      {/* Top gradient line */}
      <div className={cn(
        'absolute top-0 left-0 right-0 h-px',
        verified 
          ? 'bg-gradient-to-r from-emerald-500/50 via-emerald-400/20 to-transparent'
          : 'bg-gradient-to-r from-amber-500/50 via-amber-400/20 to-transparent'
      )} />

      {/* Hover glow */}
      <div className="absolute -inset-px bg-gradient-to-r from-pip-500/0 via-pip-500/5 to-pip-500/0 opacity-0 group-hover:opacity-100 blur-xl transition-opacity duration-500" />

      <div className="relative z-10">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs font-bold text-pip-400 bg-pip-500/10 px-2 py-0.5 rounded">
                {code}
              </span>
              <span className={cn(
                'w-2 h-2 rounded-full',
                verified ? 'bg-emerald-400' : 'bg-amber-400'
              )} />
            </div>
            <h3 className="mt-2 text-base font-semibold text-white group-hover:text-pip-300 transition-colors">
              {name}
            </h3>
            <p className="text-xs text-zinc-500 flex items-center gap-1 mt-0.5">
              <MapPin className="w-3 h-3" />
              {district}
            </p>
          </div>
          <ChevronRight className="w-4 h-4 text-zinc-600 group-hover:text-pip-400 group-hover:translate-x-1 transition-all" />
        </div>

        {/* Data completeness bar */}
        <div className="mb-4">
          <div className="flex items-center justify-between text-[10px] text-zinc-500 mb-1">
            <span>Data completeness</span>
            <span className="font-mono">{completeness}%</span>
          </div>
          <div className="h-1.5 bg-zinc-800 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${completeness}%` }}
              transition={{ duration: 1, delay: delay + 0.3, ease: 'easeOut' }}
              className={cn(
                'h-full rounded-full',
                verified 
                  ? 'bg-gradient-to-r from-emerald-500 to-emerald-400'
                  : 'bg-gradient-to-r from-amber-500 to-amber-400'
              )}
            />
          </div>
        </div>

        {/* Stats row */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <Building2 className="w-3.5 h-3.5 text-zinc-500" />
            <span className="font-mono text-sm text-zinc-300">{dunCount}</span>
            <span className="text-[10px] text-zinc-600">DUN</span>
          </div>
          <div className="w-px h-3 bg-zinc-800" />
          <div className="flex items-center gap-1.5">
            <Users className="w-3.5 h-3.5 text-zinc-500" />
            {voters ? (
              <span className="font-mono text-sm text-zinc-300">
                {voters.toLocaleString()}
              </span>
            ) : (
              <span className="font-mono text-sm text-zinc-600">—</span>
            )}
            <span className="text-[10px] text-zinc-600">voters</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
