'use client';

import { cn } from '@/lib/utils';

export function SkeletonCard({ className }: { className?: string }) {
  return (
    <div className={cn(
      'rounded-xl bg-white/[0.03] border border-white/[0.08] p-6',
      className
    )}>
      <div className="space-y-4">
        <div className="h-4 w-20 rounded bg-zinc-800 shimmer" />
        <div className="h-8 w-32 rounded bg-zinc-800 shimmer" />
        <div className="h-3 w-full rounded bg-zinc-800 shimmer" />
        <div className="h-1.5 w-full rounded-full bg-zinc-800 overflow-hidden">
          <div className="h-full w-1/3 rounded-full bg-zinc-700 shimmer" />
        </div>
      </div>
    </div>
  );
}
