'use client';

import { motion } from 'framer-motion';
import { useEffect, useState, useRef } from 'react';
import { cn } from '@/lib/utils';

interface StatCardProps {
  value: number;
  label: string;
  suffix?: string;
  prefix?: string;
  description?: string;
  verified?: boolean;
  delay?: number;
  className?: string;
  large?: boolean;
}

function AnimatedNumber({ value, prefix = '', suffix = '' }: { value: number; prefix?: string; suffix?: string }) {
  const [display, setDisplay] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const [hasAnimated, setHasAnimated] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasAnimated) {
          setHasAnimated(true);
          const duration = 2000;
          const startTime = performance.now();
          const animate = (currentTime: number) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3); // ease-out cubic
            setDisplay(Math.floor(eased * value));
            if (progress < 1) requestAnimationFrame(animate);
          };
          requestAnimationFrame(animate);
        }
      },
      { threshold: 0.5 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [value, hasAnimated]);

  return (
    <span ref={ref} className="font-mono tabular-nums">
      {prefix}{display.toLocaleString()}{suffix}
    </span>
  );
}

export function StatCard({
  value,
  label,
  suffix = '',
  prefix = '',
  description,
  verified = true,
  delay = 0,
  className,
  large = false,
}: StatCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] }}
      className={cn(
        'group relative overflow-hidden rounded-xl',
        'bg-white/[0.03] backdrop-blur-xl',
        'border border-white/[0.08]',
        'hover:border-pip-500/20 hover:bg-white/[0.05]',
        'transition-all duration-300',
        'shadow-card hover:shadow-card-hover',
        large ? 'p-8' : 'p-6',
        className
      )}
    >
      {/* Subtle gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-pip-500/[0.02] to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

      {/* Glow effect on hover */}
      <div className="absolute -inset-px bg-gradient-to-r from-pip-500/0 via-pip-500/10 to-pip-500/0 opacity-0 group-hover:opacity-100 blur-xl transition-opacity duration-500" />

      <div className="relative z-10">
        {/* Status badge */}
        <div className="flex items-center gap-2 mb-3">
          <span className={cn(
            'inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-medium tracking-wide uppercase',
            verified 
              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
              : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
          )}>
            <span className={cn(
              'w-1.5 h-1.5 rounded-full',
              verified ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'
            )} />
            {verified ? 'Verified' : 'Pending'}
          </span>
        </div>

        {/* Value */}
        <div className={cn(
          'font-mono font-bold tracking-tight text-white',
          large ? 'text-5xl' : 'text-3xl'
        )}>
          <AnimatedNumber value={value} prefix={prefix} suffix={suffix} />
        </div>

        {/* Label */}
        <div className="mt-2 text-sm font-medium text-zinc-400">
          {label}
        </div>

        {/* Description */}
        {description && (
          <div className="mt-1 text-xs text-zinc-500">
            {description}
          </div>
        )}
      </div>
    </motion.div>
  );
}
