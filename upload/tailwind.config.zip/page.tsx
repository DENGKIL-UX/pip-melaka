'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Navigation } from '@/components/Navigation';
import { BentoHero } from '@/components/BentoHero';
import { ParliamentCard } from '@/components/ParliamentCard';
import { CommandPalette } from '@/components/CommandPalette';
import { SkeletonCard } from '@/components/SkeletonCard';
import { ArrowUpRight, Activity, Shield } from 'lucide-react';

const parliaments = [
  { code: 'P134', name: 'Masjid Tanah', district: 'Alor Gajah', dunCount: 5, voters: 71415, verified: true },
  { code: 'P135', name: 'Alor Gajah', district: 'Alor Gajah', dunCount: 5, voters: null, verified: false },
  { code: 'P136', name: 'Tangga Batu', district: 'Melaka Tengah', dunCount: 4, voters: null, verified: false },
  { code: 'P137', name: 'Hang Tuah Jaya', district: 'Melaka Tengah', dunCount: 4, voters: null, verified: false },
  { code: 'P138', name: 'Kota Melaka', district: 'Melaka Tengah', dunCount: 5, voters: null, verified: false },
  { code: 'P139', name: 'Jasin', district: 'Jasin', dunCount: 5, voters: null, verified: false },
];

export default function HomePage() {
  const [commandOpen, setCommandOpen] = useState(false);

  return (
    <div className="min-h-screen bg-zinc-950 text-white">
      <Navigation />
      <CommandPalette open={commandOpen} onClose={() => setCommandOpen(false)} />

      {/* Hero Section */}
      <section className="pt-32 pb-16 px-4">
        <div className="max-w-5xl mx-auto">
          {/* Tagline */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full 
              bg-pip-500/10 border border-pip-500/20 mb-6">
              <Activity className="w-3.5 h-3.5 text-pip-400" />
              <span className="text-xs font-medium text-pip-400 tracking-wider uppercase">
                Live Dashboard
              </span>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-4">
              Truth Above All
            </h1>
            <p className="text-lg text-zinc-400 max-w-2xl mx-auto">
              Political Intelligence Platform for Melaka — real DOSM boundaries, 
              build-time demographics, zero PDPA exposure.
            </p>
          </motion.div>

          <BentoHero />
        </div>
      </section>

      {/* Parliaments Section */}
      <section className="py-16 px-4" id="parliaments">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="flex items-center justify-between mb-8"
          >
            <div>
              <h2 className="text-2xl font-bold text-white">Parliaments</h2>
              <p className="text-sm text-zinc-500 mt-1">
                6 constituencies · 3 districts · Verified against DOSM kawasanku
              </p>
            </div>
            <div className="flex items-center gap-2 text-xs text-zinc-500">
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              <span>1/6 verified</span>
            </div>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {parliaments.map((p, i) => (
              <ParliamentCard
                key={p.code}
                {...p}
                delay={i * 0.05}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-white/[0.06]">
        <div className="max-w-5xl mx-auto flex items-center justify-between text-xs text-zinc-600">
          <span>PIP-MLK · Political Intelligence Platform</span>
          <span className="font-mono">v1.0.0</span>
        </div>
      </footer>
    </div>
  );
}
